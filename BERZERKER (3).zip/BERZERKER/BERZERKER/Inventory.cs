﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BERZERKER
{
    class Inventory 
    {

        public string Name;
        public double Capacity;

        public Inventory(string name, double capacity)
        {
            Name = name;
            Capacity = capacity;

        }

        public void Storage1()
        {
            Name = "Ragged Backpack";
            Capacity = 7;
        }

        public void Storage2()
        {
            Name = "Sachel";
            Capacity = 5;

        }

        public void Storage3()
        {
            Name = "Duffel Bag";
            Capacity = 12;
        }

        public void Storage4()
        {
            Name = "Travelers Backpack";
            Capacity = 20;
        }

        public void Storage5()
        {
            Name = "Travel Pack";
            Capacity = 4;
        }

        //Players Inventory:
        //Players should be able to have access to items that they currently have.
        //Item capacity depends on equipment has...

        //Storage Items can acquire:
        ///* "Ragged Backpack" | Capacity: 7 Items
        ///* "Sachel" | Capacity: 5 Items
        ///* "Duffel Bag" | Capacity: 12
        ///* "Travelers Backpack" | Capacity: 20 Items
        ///* "Travel Pack/Fanny Pack"| Capacity: 4 Items (It counts more as extra storage, so  you basically have and extra storage slot...)

        //Weapons can acquire/Craft:
        ///* "Axe" | Damage: 6
        ///* "Switchblade" | Damage: 2  (Honestly I dare you to use this throughout the whole game without using any other weapon...No first aid either...)
        ///* "Pistol" | Damage: 10
        ///* "Shotgun" | Damage: 16
        ///* "Rifle" | Damage: 12
        ///* "Baseball Bat (or bat)| Damage: 8
        ///* "Katana" | Damage: 9
        ///* "Machete" | Damage: 10
        ///* "Grenade" | Damage: 20
        ///* "Flamethrower" | Damage: 25
        ///* "Molotav" | Damage: 23

        //Material can acquire/Craft:
        ///* "First-Aid Kit" | +100 Health
        ///* "Bandage" | +5 Health
        ///* "Morphine" | +25 Health, -5 Speed
        ///* "Pistol Ammo" | Quanity: Random
        ///* "Shotgun Ammo"| Quanity: Random
        ///* "Rifle Ammo" | Quanity: Random
        ///* "Pain-killers" | +15 Health
        ///* "Scrap" | Quanity: Random
        ///* "Sticks" | Quanity: Random
        ///* "Rope" | Quanity: Random
        ///* "Cloth" | Quanity: Random
        ///* "Rock" | Quanity: Random
        ///* "Batteries" | Quanity: Random
        ///* "Herb B" | +20 Health, -15 Speed
        ///* 




        //Day 1:
        //Players have a "Ragged Backpack" - The backpack is worn and can only capacitize up to 7 things.
        //A first-aid kit, pain-killers, ammo for a pistol(x6), and 5 bandages, with 4 cans of food, and 3 bottles of water.
    }
}
