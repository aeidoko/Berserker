﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BERZERKER
{
    class Items
    {
        public string Name;
        private string Type;
        private double Damage;
        private bool Heal;
        private bool Ammo;
        

        public Items(string name, string type,double damage, bool heal, bool ammo)
        {
            Name = name;
            Type = type;
            Damage = damage;
            Heal = heal;
            Ammo = ammo;
        }

        public void Item1()
        {
            Name = "Axe";
            Type = "Melee";
            Damage = 6;
            Heal = false;
            Ammo = false;
        }

        public void Item2()
        {
            Name = "Switchblade";
            Type = "Melee";
            Damage = 2;
            Heal = false;
            Ammo = false;
        }

        public void Item3()
        {
            Name = "Pistol";
            Type = "Ranged";
            Damage = 10;
            Heal = false;
            Ammo = false;
        }

        public void Item4()
        {
            Name = "Shotgun";
            Type = "Ranged";
            Damage = 16;
            Heal = false;
            Ammo = false;
        }

        public void Item5()
        {
            Name = "Rifle";
            Type = "Ranged";
            Damage = 12;
            Heal = false;
            Ammo = false;
        }

        public void Item6()
        {
            Name = "Baseball Bat";
            Type = "Melee";
            Damage = 8;
            Heal = false;
            Ammo = false;
        }

        public void Item7()
        {
            Name = "Katana";
            Type = "Melee";
            Damage = 9;
            Heal = false;
            Ammo = false;
        }

        public void Item8()
        {
            Name = "Machete";
            Type = "Melee";
            Damage = 10;
            Heal = false;
            Ammo = false;
        }

        public void Item9()
        {
            Name = "Grenade";
            Type = "Explosive";
            Damage = 20;
            Heal = false;
            Ammo = false;
        }

        public void Item10()
        {
            Name = "Flamethrower";
            Type = "Ranged";
            Damage = 25;
            Heal = false;
            Ammo = false;
        }

        public void Item11()
        {
            Name = "Molotav";
            Type = "Ranged";
            Damage = 23;
            Heal = false;
            Ammo = false;
        }

        public void Item12()
        {
            Name = "First-aid Kit";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }

        public void Item13()
        {
            Name = "Bandage";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }

        public void Item14()
        {
            Name = "Morphine";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }

        public void Item15()
        {
            Name = "Pistol Ammo";
            Type = "Weapon Ammunition";
            Heal = false;
            Ammo = true;
        }
          
        public void Item16()
        {
            Name = "Shotgun Ammo";
            Type = "Weapon Ammunition";
            Heal = false;
            Ammo = true;
        }

        public void Item17()
        {
            Name = "Rifle Ammo";
            Type = "Weapon Ammunition";
            Heal = false;
            Ammo = true;
        }

        public void Item18()
        {
            Name = "Pain killers";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }

        public void Item19()
        {
            Name = "Scrap";
            Type = "Material";
            Heal = false;
            Ammo = false;
        }

        public void Item20()
        {
            Name = "Stick";
            Type = "Material";
            Heal = false;
            Ammo = false;
        }

        public void Item21()
        {
            Name = "Rope";
            Type = "Material";
            Heal = false;
            Ammo = false;
        }

        public void Item22()
        {
            Name = "Cloth";
            Type = "Material";
            Heal = false;
            Ammo = false;
        }

        public void Item23()
        {
            Name = "Rock";
            Type = "Material";
            Heal = false;
            Ammo = false;
        }

        public void Item24()
        {
            Name = "Batteries";
            Type = "Material";
            Heal = false;
            Ammo = false;
        }

        public void Item25()
        {
            Name = "Herb B";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }

        public void Item26()
        {
            Name = "Herb A";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }

        public void Item27()
        {
            Name = "Herb C";
            Type = "Health Item";
            Heal = true;
            Ammo = false;
        }


        //Weapons can acquire/Craft:
        ///* "Axe" | Damage: 6
        ///* "Switchblade" | Damage: 2  (Honestly I dare you to use this throughout the whole game without using any other weapon...No first aid either...)
        ///* "Pistol" | Damage: 10
        ///* "Shotgun" | Damage: 16
        ///* "Rifle" | Damage: 12
        ///* "Baseball Bat (or bat)| Damage: 8
        ///* "Katana" | Damage: 9
        ///* "Machete" | Damage: 10
        ///* "Grenade" | Damage: 20
        ///* "Flamethrower" | Damage: 25
        ///* "Molotav" | Damage: 23

        //Material can acquire/Craft:
        ///* "First-Aid Kit" | +100 Health
        ///* "Bandage" | +5 Health
        ///* "Morphine" | +25 Health, -5 Speed
        ///* "Pistol Ammo" | Quanity: Random
        ///* "Shotgun Ammo"| Quanity: Random
        ///* "Rifle Ammo" | Quanity: Random
        ///* "Pain-killers" | +15 Health
        ///* "Scrap" | Quanity: Random
        ///* "Sticks" | Quanity: Random
        ///* "Rope" | Quanity: Random
        ///* "Cloth" | Quanity: Random
        ///* "Rock" | Quanity: Random
        ///* "Batteries" | Quanity: Random
        ///* "Herb B" | +20 Health, -15 Speed
        ///* "Herb A" | +20 Health, +15
        ///* "Herb C" | -20 Health, +15



    }
}
