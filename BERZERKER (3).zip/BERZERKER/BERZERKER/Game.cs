﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using static System.Console;

namespace BERZERKER
{
    class Game
    {


        public void Play()
        {
            ///Game Menu:

            string TitleScreen = @"
 ▄▄▄▄   ▓█████  ██▀███  ▒███████▒▓█████  ██▀███   ██ ▄█▀▓█████  ██▀███  
▓█████▄ ▓█   ▀ ▓██ ▒ ██▒▒ ▒ ▒ ▄▀░▓█   ▀ ▓██ ▒ ██▒ ██▄█▒ ▓█   ▀ ▓██ ▒ ██▒
▒██▒ ▄██▒███   ▓██ ░▄█ ▒░ ▒ ▄▀▒░ ▒███   ▓██ ░▄█ ▒▓███▄░ ▒███   ▓██ ░▄█ ▒
▒██░█▀  ▒▓█  ▄ ▒██▀▀█▄    ▄▀▒   ░▒▓█  ▄ ▒██▀▀█▄  ▓██ █▄ ▒▓█  ▄ ▒██▀▀█▄  
░▓█  ▀█▓░▒████▒░██▓ ▒██▒▒███████▒░▒████▒░██▓ ▒██▒▒██▒ █▄░▒████▒░██▓ ▒██▒
░▒▓███▀▒░░ ▒░ ░░ ▒▓ ░▒▓░░▒▒ ▓░▒░▒░░ ▒░ ░░ ▒▓ ░▒▓░▒ ▒▒ ▓▒░░ ▒░ ░░ ▒▓ ░▒▓░
▒░▒   ░  ░ ░  ░  ░▒ ░ ▒░░░▒ ▒ ░ ▒ ░ ░  ░  ░▒ ░ ▒░░ ░▒ ▒░ ░ ░  ░  ░▒ ░ ▒░
 ░    ░    ░     ░░   ░ ░ ░ ░ ░ ░   ░     ░░   ░ ░ ░░ ░    ░     ░░   ░ 
 ░         ░  ░   ░       ░ ░       ░  ░   ░     ░  ░      ░  ░   ░     
      ░                 ░                                               
";


            string TitleArt = @"";

            WriteLine(TitleScreen);
            WriteLine(TitleArt);
            WriteLine();
            WriteLine();
            WriteLine("Play|Load|Quit");
            WriteLine();

            string playerChoice = ReadLine();


            if (playerChoice == "Play" || playerChoice == "play")
            {
                //Players start at Day 1:
                Clear();
                Day1();
                Day2();
                Day3();
                playAgain();
            }

        }

       

        public void Day1()
        {
            
            WriteLine("As you wake up you can smell a mix of blood and metal in the air.\nYou try to see what is in your field of view but it is too blurry.\nYou try to get to an area where you can rest and conserve your energy and stumble into a small building.");
            WriteLine();
            WriteLine(". . .");
            WriteLine();
            WriteLine("You lay against the wall, almost passing out from the energy you exert from small movements.");
            WriteLine();
            WriteLine("What would you like to do?");
            WriteLine();
            WriteLine("[a] - Heal Your Wound");
            WriteLine("[b] - Look Around");
            WriteLine("[c] - Do Nothing");

            string playerChoice = ReadLine();
            if (playerChoice == "a")
            {
                
                WriteLine();
                WriteLine("You find you are bleeding out from a wound on your stomach.\nYou begin tending to the wound, despite your sluggishness.");
                WriteLine();
                WriteLine("After awhile of patching up your wound.\nYou sluggishly stand up and survey the areas around the room.\nYou look outside to find there are quite a few infected outside.");
                WriteLine("You figure since you lack the energy to move due to your wound, you might as well take shelter inside this small building.\nYou find the safest area of the building to sleep.\nThe day has ended.");
                
            }

            if (playerChoice == "b")
            {
                
                WriteLine("You look around to find a mostly barren room.\nThe floor is covered in ash, and all you smell is smoke throughout the room.\nThe only light is coming from a window with which the glass broken.");
                WriteLine("As you look around you find yourself growing more tired as movement excerpts your energy.\nYou decide to stay inside the small building to make it a temporary shelter.\nYou decide to find a safe area of the room to sleep.\nThe day has ended");
            }
            if (playerChoice == "c")
            {
                
                WriteLine("You sit there with the smell of burnt materials lingering in your nose.\nYou eventually succumb to fatigue and decide to stay inside the small building to make it a temporary shelter.\nYou decide to find a safe area of the room to sleep.\nThe day has ended");
            }
            else
            {

            }
            
        }


        public void Day2()
        {
            
            WriteLine("It is morning and you wake up a little less sluggish this time.\nYou find that the infected are gone, and there is a long blood trail leading to a wreakage somewhere in the area.\nYou question if its the best course of action to follow the trail or to set a task to look for supplies.");
            WriteLine();
            WriteLine("What would you like to do?");
            WriteLine();
            WriteLine("[a] - Examine blood trail");
            WriteLine("[b] - Look for resources around the area");
            WriteLine("[c] - Return to the small building");
            
            string playerChoice = ReadLine();
            if (playerChoice == "a")
            {
                WriteLine("You look at the blood trail and notice that it leads to a crash site.\nYou look around to see a helicopter that is completely wrecked.\nAs you walk following the blood trail, you find a pair of legs hanging out from inside the wreckage.\nThe person seems to have lost the upper half of their body...\nYou writhe a little having found the grizzly scene.\nYou notice a duffel bag that also lies in the wreckage, it looks to be in pretty decent condition despite the immence amount of damage around it.\nYou grab the duffel bag and look into it, its contents being food,medical supplies and some other small resources.\nYou take the duffel bag back to your small shelter area.\nIt is nighttime and you prepare for the gruelling day ahead.\nThe second day has come to an end.");
            }
            if (playerChoice == "b")
            {
                WriteLine("You look around to find some small resources in abandoned, and destoryed areas.\nYou find a ragedy backpack from inside a broken down car and put whatever little resources you have into the worn bag.\nYou return to your shelter with a small amount of resources that being: Small amounts of food, and medical supplies.\nThe second day has come to an end.");
            }
            if (playerChoice == "c")
            {
                WriteLine("You come back with little to no resources at all and instead fall asleep with hopes to find more resources in the morning.\nThe second day has come to an end.");
            }
            
        }

        public void Day3()
        {
            
            WriteLine("You wake up early this time, to find that their are some noises coming from outside.\nYou proceed to look outside to find that there are some people outside searching the area.\nYou are mixingly curious but also worried because you aren't sure if you should confront these people head on.\nWhat exactly might these people want?");
            WriteLine();
            WriteLine("What would you like to do?");
            WriteLine();
            WriteLine("[a] - Try and talk to them");
            WriteLine("[b] - Fight them");
            WriteLine("[c] - Do nothing");

            string playerChoice = ReadLine();
            if (playerChoice == "a")
            {
                WriteLine("You go over and interact with them and you find out that they are actually an organized group that is rescuing survivors that they come across inside their carvan.\nToday you are the 11th person they have met and offer you a better place to call home.\nA place called 'Heavens Door'.");
                
            }
            if (playerChoice == "b")
            {
                WriteLine("You attempt to fight them but you only find yourself being attacked by them.\nEventually one of them not taking to kindly to your hostility gets agitated and you find yourself with lead in your frontal lobe.");
                WriteLine("Game Over!");
            }

            if (playerChoice == "c")
            {
                WriteLine("You do nothing.\nYou refuse to move from your little sanctuary and eventually they get tired of looking around and leave.\nYou are left alone by yourself with no resources or anything to fend yourself off.\nYou eventually succumb to starvation.");
                WriteLine("Game Over!");
            }
            
        }

        public void playAgain()
        {
            WriteLine();
            WriteLine("Would you like to play again?");

            string playerChoice = ReadLine();
            if (playerChoice == "yes" || playerChoice == "Yes")
            {
                Clear();
                Play();
            }
        }


    }
}
