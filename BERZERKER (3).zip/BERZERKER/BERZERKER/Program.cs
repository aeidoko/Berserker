﻿using System;

namespace BERZERKER
{
    class Program
    {
        static void Main(string[] args)
        {
            Game gameStart = new Game();
            gameStart.Play();
        }
    }
}
