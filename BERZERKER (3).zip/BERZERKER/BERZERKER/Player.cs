﻿using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using static System.Console;

namespace BERZERKER
{
    class Player 
    {
        // private string Chara = "Leia Elwreich";

        public string Username;
        public double Level;

        public double Health;
        public double Hunger;
        public double Thirst;
        public double Sanity;

        public double Strength;
        public double Perception;
        public double Endurance;
        public double Charisma;
        public double Intelligence;
        public double Agility;
        public double Luck;

        public double Kash;

        public void PlayerStatus(string username, double level, double health, double hunger, double thirst, double sanity, double strength, double perception, double endurance,double charisma,double intelligence,double agility, double luck)
        {
          // Player Information & Stats
            Username = username;
            Level = level;

            Health = health;
            Hunger = hunger;
            Thirst = thirst;
            Sanity = sanity;

            Strength = strength;
            Perception = perception;
            Endurance = endurance;
            Charisma = charisma;
            Intelligence = intelligence;
            Agility = agility;
            Luck = luck;

            //Default Stats:

            //These are the stats players should have starting the game, they can add to their stats by making choices in game.

            //Players should be able to put in a username.
            // username = ReadLine(); (For now I'll just make this into a comment...)
            level = 0;

            health = 100;
            hunger = 100;
            thirst = 100;
            sanity = 100;

            strength = 0;
            perception = 0;
            endurance = 0;
            charisma = 0;
            intelligence = 0;
            agility = 0;
            luck = 0;

            Kash = 0;


            string playerChoice = ReadLine();
            if (playerChoice == "T" || playerChoice == "t")
            {
                WriteLine("Would you like to see your player status?");

                if (playerChoice == "Yes" || playerChoice == "yes")
                //Displaying Player info & Stats:
                WriteLine($"Username:{username}");
                WriteLine($"Kash:{Kash}");
                WriteLine($"Level:{level}");
                WriteLine();
                WriteLine($"Health:{health}/100");
                WriteLine($"Hunger:{hunger}/100");
                WriteLine($"Thrist:{thirst}/100");
                WriteLine($"Sanity:{sanity}/100");
                WriteLine();
                WriteLine($"Strength:{strength}");
                WriteLine($"Perception:{perception}");
                WriteLine($"Endurance:{endurance}");
                WriteLine($"Charisma:{charisma}");
                WriteLine($"Intelligence:{intelligence}");
                WriteLine($"Agility:{agility}");
                WriteLine($"Luck:{luck}");
            }

            if (playerChoice == "No" || playerChoice == "no")
            {
                WriteLine();
            }
        
            else
            {
                WriteLine("You do not move...");
            }
        }

        
        



        //------------------------------------------------------------------------------------------------------

        ///Player Stats:

        //Username: [string]
        //Level: #

        //Health: #/100
        //Hunger: #/100
        //Thrist: #/100
        //Sanity: #/100

        //Strength: "?"
        //Perception: "?"
        //Endurance: "?"
        //Charisma: "?"
        //Intelligence: "?"
        //Agility: "?"
        //Luck: "?"

        // Though they all default to "?" because it cannot yet be determined if you haven't played it yet.
        // The stats change based on the choices that you make in game...
        //---------------------------------------------------------------------------------------------------

        ///
    }
}
