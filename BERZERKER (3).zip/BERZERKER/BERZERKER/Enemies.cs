﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BERZERKER
{
    class Enemies
    {
        public string Name;
        public string Type;
        public double Health;
        public double Level;

        public Enemies(string name, string type, double health, double level)
        {
            Name = name;
            Type = type;
            Health = health;
            Level = level;
            
        }
        


    }
}
